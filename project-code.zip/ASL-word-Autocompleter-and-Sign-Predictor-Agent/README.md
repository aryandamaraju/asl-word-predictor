# ASL-word-Autocompleter-and-Sign-Predictor-Agent
##Dataset
The dataset used in this project  can be downloaded from:
https://drive.google.com/drive/folders/1KmF2AiPHlhFOQVMccrOXldKeg5f8W_Yt?usp=drive_link

The requirement.txt file is needed to run any of the scripts except for train_video.py for that one, make a separate environment and install requirements_video.txt